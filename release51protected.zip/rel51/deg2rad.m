function uscita = deg2rad(ingresso)
uscita = 2*pi*ingresso/360;